create view departments_total_salary(dept_name, total_salary) as
SELECT instructor.dept_name,
       sum(instructor.salary) AS total_salary
FROM instructor
GROUP BY instructor.dept_name;

alter table departments_total_salary
    owner to postgres;

