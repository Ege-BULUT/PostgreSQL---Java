create view physics_fall_2009(course_id, sec_id, building, room_number, semester, year) as
SELECT course.course_id,
       section.sec_id,
       section.building,
       section.room_number,
       section.semester,
       section.year
FROM course,
     section
WHERE course.course_id::text = section.course_id::text
  AND course.dept_name::text = 'Physics'::text
  AND section.semester::text = 'Fall'::text;

alter table physics_fall_2009
    owner to postgres;

